<?php
if ( !defined( 'ABSPATH' ) ) {
	exit;
}
?>
<p>
	<?php esc_html_e( 'Booking is already canceled.', 'motopress-hotel-booking' ); ?>
</p>
