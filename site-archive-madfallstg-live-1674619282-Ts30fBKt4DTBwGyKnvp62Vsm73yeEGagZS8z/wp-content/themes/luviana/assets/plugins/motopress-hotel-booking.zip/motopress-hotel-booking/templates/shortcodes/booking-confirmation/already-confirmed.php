<?php
if ( !defined( 'ABSPATH' ) ) {
	exit;
}
?>
<p>
	<?php esc_html_e( 'Booking is already confirmed.', 'motopress-hotel-booking' ); ?>
</p>